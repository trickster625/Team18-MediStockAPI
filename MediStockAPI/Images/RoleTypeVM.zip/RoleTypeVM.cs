﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MediStockAPI.Models
{
    public class RoleTypeVM
    {
        public int RoleType_ID { get; set; }
        public string RoleType_Description { get; set; }
    }
}